import React, { useState } from "react";
import { jsPDF } from "jspdf";

export default function App() {
  const [topic, setTopic] = useState("");
  const [showGenerator, setShowGenerator] = useState(false);
  const [results, setResults] = useState({
    titles: ["Título de ejemplo 1", "Título de ejemplo 2"],
    description: "Descripción de ejemplo optimizada.",
    hashtags: "#ejemplo #contenido #utubeando"
  });
  const [imagePrompt, setImagePrompt] = useState("Imagen visual para representar el contenido.");
  const [imageUrl, setImageUrl] = useState("");
  const [isLoadingImage, setIsLoadingImage] = useState(false);

  const generarImagen = async () => {
    setIsLoadingImage(true);
    const response = await fetch(`https://api.dicebear.com/7.x/shapes/svg?seed=${encodeURIComponent(topic)}`);
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    setImageUrl(url);
    setIsLoadingImage(false);
  };

  const descargarImagen = () => {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = 'miniatura_generada.svg';
    link.click();
  };

  const downloadAsPDF = async () => {
    if (!results) return;
    const doc = new jsPDF();

    const today = new Date();
    const dateString = today.toLocaleDateString("es-PE", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });

    const base64Logo = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEsAAABLCAMAAACLU5NGAAABHlBMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////+6URUeAAAAIXRSTlMA9LTp1M3Dw7BGBhAL/fv2WV8cFZacOypzRjIdEyUlEZGGUtiMpnm2ywAAAHwSURBVHja7ZXbcoMwEEWz7Luw//+QhKSo0a3LDeOn1IgjG4HJpgvTJkAwM7EbBRP6V9J3q2ehAj8bL41EEgxy5FbSBPeAcTFFhyoHVR9FdtfYtaDbVV5JS1DJq4Oa2nM5e1bTfbZPqeJ2m5vb2f7+Xq/bVTXU7MxXPxGnb13GrHV9fNDbRvpTbskOj3S/xnGdmiM2A/9EUN40l6VZnOWkXyBzT2AxziFg/vZiJGvnBM7xfjJqFPRsMyTgff8rrZwhRM2AzKOE6NSoJQQmGWmFEIUlkkqxQkbTeWkaMKwXhKMmbUgIrd9lAoUpeKVIVoCRjHGZJDPDIgVr5E3k1YoX65+vWICkUnj0lHgGnSCJ3X1XMcRbphd1X3+uwIQc5jFjqMnUAAAAASUVORK5CYII=";

    doc.addImage(base64Logo, "PNG", 10, 10, 40, 40);
    doc.setFontSize(16);
    doc.text("Academia ALFA - Generador de Contenido", 55, 25);
    doc.setFontSize(11);
    doc.setTextColor(100);
    doc.text(`Fecha de generación: ${dateString}`, 55, 32);
    doc.setFontSize(14);
    doc.setTextColor(0, 0, 0);
    doc.text(`Tema del video: ${topic}`, 10, 55);
    doc.setFontSize(12);

    let y = 70;
    doc.text("TÍTULOS:", 10, y);
    results.titles.forEach((title, i) => {
      doc.text(`- ${title}`, 10, y + 10 + i * 10);
    });
    y += 20 + results.titles.length * 10;

    doc.text("DESCRIPCIÓN:", 10, y);
    doc.text(doc.splitTextToSize(results.description, 180), 10, y + 10);
    y += 20 + doc.splitTextToSize(results.description, 180).length * 10;

    doc.text("HASHTAGS:", 10, y);
    doc.text(doc.splitTextToSize(results.hashtags, 180), 10, y + 10);
    y += 20 + doc.splitTextToSize(results.hashtags, 180).length * 10;

    doc.text("PROMPT PARA MINIATURA (en inglés):", 10, y);
    doc.text(doc.splitTextToSize(imagePrompt, 180), 10, y + 10);

    const quote = "Ofrezco valor real desde mi experiencia, para que tu camino sea más ligero.";
    const link = "https://www.youtube.com/channel/UCUcLq16veLsDRSHZG3Qg5vA";
    const pageCount = doc.internal.getNumberOfPages();
    for (let i = 1; i <= pageCount; i++) {
      doc.setPage(i);
      doc.setFontSize(10);
      doc.setTextColor(150);
      doc.text(quote, 105, 282, { align: "center" });
      doc.setTextColor(100, 100, 255);
      doc.textWithLink("Visita mi canal: YouTube.com/AcademiaAlfa", 105, 288, { align: "center", url: link });
    }

    doc.save(`contenido_youtube_${Date.now()}.pdf`);
  };

  if (!showGenerator) {
    return (
      <div style={{ padding: "2rem", textAlign: "center" }}>
        <h1 style={{ fontSize: "2rem", marginBottom: 10 }}>Bienvenido a Alfa Studio Pro ✨</h1>
        <p style={{ marginBottom: 30 }}>
          Genera títulos, descripciones y miniaturas irresistibles para tus videos de YouTube.
        </p>
        <button
          onClick={() => setShowGenerator(true)}
          style={{ padding: "1rem 2rem", fontSize: "1rem", cursor: "pointer" }}
        >
          Empezar Ahora
        </button>
      </div>
    );
  }

  return (
    <div style={{ padding: "2rem" }}>
      <h2>Generador de Contenido para YouTube</h2>
      <input
        style={{ width: "100%", padding: "0.5rem", marginBottom: "1rem" }}
        value={topic}
        onChange={(e) => setTopic(e.target.value)}
        placeholder="Ingresa el tema del video..."
      />
      <button onClick={downloadAsPDF} style={{ padding: "0.5rem 1rem" }}>
        Descargar PDF
      </button>
    </div>
  );
}
